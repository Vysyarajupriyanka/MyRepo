sap.ui.define([
	"LoginPoc/LoginPoc/test/unit/controller/app.controller"
], function () {
	"use strict";
});