sap.ui.define([
	"sap/ui/core/mvc/Controller","sap/m/MessageToast","sap/ui/table/Table","sap/ui/commons/Label","sap/ui/commons/TextView","sap/ui/commons/TextField"
], function (Controller,MessageToast,Table) {
	"use strict";
	var a=[];
  
     var oTable = new sap.ui.table.Table({title:"USER DETAILS", visibleRowCount: 3, selectionMode: sap.ui.table.SelectionMode.Single, 
    navigationMode: sap.ui.table.NavigationMode.Paginator,width:"1024px"
    });
  
	return Controller.extend("LoginPoc.LoginPoc.controller.Home", {
      
	  
		onInit: function () {
        
		},
        getdata: function(){
        	
        	var oModel=new sap.ui.model.json.JSONModel();
        	var that=this;
        	var oData=jQuery.ajax({
        		type: "GET",
        		contentType: "application/json",
        		url:   "https://reqres.in/api/users?page=2",
        		dataType: "json",
        		async: "false",
        		error: function(jqXHR,textStatus,errorThrown) {
                alert("failed get Results");
                },
        		success :function(data,textStatus,jqXHR){
        		  a=data.data;
        			oModel.setData({Modeldata:a});
        			
        			oTable.bindRows("/modelData");
        			  oTable.addColumn(new sap.ui.table.Column({
                label : new sap.ui.commons.Label({text : "ID"}),               
            template : new sap.ui.commons.TextField().bindProperty("value","id") ,filterProperty: "id"              
        }));
         oTable.addColumn(new sap.ui.table.Column({
                label : new sap.ui.commons.Label({text : "email"}),               
            template : new sap.ui.commons.TextField().bindProperty("value","/email"),filterProperty: "email"                 
        }));

        oTable.addColumn(new sap.ui.table.Column({
            label : new sap.ui.commons.Label({text : "first_name"}),              
            template : new sap.ui.commons.TextField().bindProperty("value","first_name") ,filterProperty: "first_name"
        }));

        oTable.addColumn(new sap.ui.table.Column({
            label : new sap.ui.commons.Label({text : "last_name"}),               
            template : new sap.ui.commons.TextField().bindProperty("value","last_name"),filterProperty: "last_name"
        }));
        			  oTable.placeAt("EmpTbl");
        			console.log(data);
        		  MessageToast.show(a[0].email);
        			alert(a);
        	          
        			
        			alert("sucecess to post");
        		}
        	
        	
        	});
        	this.getView().setModel(oModel);
        	
        	 
    


		
        	return oModel;
        }
	

	});

});