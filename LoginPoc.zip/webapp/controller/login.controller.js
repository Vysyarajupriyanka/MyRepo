sap.ui.define([
	"sap/ui/core/mvc/Controller",	"sap/m/MessageToast"
], function (Controller,MessageToast) {
	"use strict";

	return Controller.extend("LoginPoc.LoginPoc.controller.login", {

		onInit: function () {

		},
		onClick: function(){
				var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
				loRouter.navTo("Home");
			},
				loginauthentication:function(payload,fnSuccess,fnError){
			
				var urli = "https://reqres.in/api/login";
				jQuery.ajax({
					type : "POST",
					url : urli,
					data :payload,
					success: function(responseData,textStatus,jqXHR)
					{
						fnSuccess(responseData,textStatus,jqXHR);
					
					},
					error: function(error){
						fnError(error);
					}
					
				});
		},
		onlogin:function(){
				var oRouter= sap.ui.core.UIComponent.getRouterFor(this);
			var a=this.getView().byId("inputEmail"); 
			var inemail=a.getValue();
			var b=this.getView().byId("passwordInput");
			var pwd=b.getValue();
			var payload={
				"email":inemail,
				"password":pwd
			};
			
		     this.loginauthentication(payload,function(data){
				// MessageToast.show("LOGIN SUCCESSFULL");
				
						oRouter.navTo("Home");
			},function(err){
				MessageToast.show("LOGIN FAILED");
			});
				
		}
	});

});